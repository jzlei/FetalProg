
#include "CStemCell.h"
#include "Random.h"
#include "BCTool.h"

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "time.h"
#include "string.h"
#include <iostream>
using namespace std;

extern int _currentgen;
extern struct IMD _MD;
extern CRandom Rand;

CStemCell::CStemCell()
{
}

CStemCell::~CStemCell()
{
    if(phead!=NULL)
    {
        DeleteChain(phead);
    }
    if(pend!=NULL)
    {
        delete pend;
    }
    if(_CpG!=NULL)
    {
        delete[] _CpG;
    }
}


bool CStemCell::Initialized(int k, char fpar[])
{
	int i;
    double theta0;
    
    SetDefaultPar();
	ReadPar(fpar);
    
    theta0 = _par.theta0;
    _par.theta0 = _par.prefactor*_par.theta0;
    
	_t = 0.0;
    _cycle=_MD.NC0;
    _kg=0;
	_cellid=k;
    _celltype=0;
	_NumVar=2;
	_NumRand=0;
    if(_CpG!=NULL)
    {
        delete[] _CpG;
    }
    _CpG = new CpGsite[_par.sitenumber];
    _NumReact=_CpG[1]._NumReact*_par.sitenumber + 2;
    
    if(_X0<0)
    {
        _R = (int)(Rand(0,100));
    }
    else
    {
        _R = _X0;
    }
    _P = _R * (_par.vp/_par.dp);
    
    _ratesupdate1();
    _ratesupdate2();

    
    for (i=0;i<_par.sitenumber; i++)
    {
        if(Rand()<0.35)
        {
            _CpG[i]._methyl[0]=1;
        }
        else
        {
            _CpG[i]._methyl[0]=0;
        }
        if(Rand()<0.35)
        {
            _CpG[i]._methyl[1]=1;
        }
        else
        {
            _CpG[i]._methyl[1]=0;
        }
        CpGsiteModification(i);
        _CpG[i].Modification(_par.tau);
    }
    _laststate = GetState();
    _state = _laststate;
    SetIniState();

    _par.theta0 = theta0;
    
    return true;
}

void CStemCell::SetIniState()
{
    _IniState.CpGstate = GetState();
    _IniState.R = _R;
    _IniState.P = _P;
}

bool CStemCell::Initialized(int k, char fpar[], int cycle, int celltype)
{
    
    SetDefaultPar();
    ReadPar(fpar);
    _t = 0.0;
    _cycle = cycle;
    _cellid = k;
    _celltype = celltype;
    
    return true;
}

void CStemCell::ReadPar(char fpar[])
{
	FILE *fp;
	char str[StrLength], *pst;
	if((fp = fopen(fpar,"r"))==NULL)
	{
		cout<<"Cannot open the cell parameter input file."<<endl;
		exit(0);
	}
	rewind(fp);
	while(!feof(fp))
	{
		fgets(str,StrLength,fp);
		if(str[0]=='#'){ continue;}

        if((pst=strstr(str,"tau="))!=NULL)
		{
			_par.tau=atof(pst+4);
		}
        if((pst=strstr(str,"f0="))!=NULL)
        {
            _par.f0=atof(pst+3);
        }
        if((pst=strstr(str,"koff="))!=NULL)
        {
            _par.koff=atof(pst+5);
        }
        if((pst=strstr(str,"d1="))!=NULL)
        {
            _par.d1=atof(pst+3);
        }
        if((pst=strstr(str,"K0="))!=NULL)
        {
            _par.K0=atof(pst+3);
        }
        if((pst=strstr(str,"K1="))!=NULL)
        {
            _par.K1=atof(pst+3);
        }
        if((pst=strstr(str,"n0="))!=NULL)
        {
            _par.n0=atof(pst+3);
        }
        if((pst=strstr(str,"m0="))!=NULL)
        {
            _par.m0=atof(pst+3);
        }
        if ((pst=strstr(str,"h0="))!=NULL)
        {
            _par.h0=atof(pst+3);
        }
        if ((pst=strstr(str,"h1="))!=NULL)
        {
            _par.h1=atof(pst+3);
        }
        if((pst=strstr(str,"d2="))!=NULL)
        {
            _par.d2=atof(pst+3);
        }
        if((pst=strstr(str,"s0="))!=NULL)
        {
            _par.s0=atof(pst+3);
        }
        if((pst=strstr(str,"r0="))!=NULL)
        {
            _par.r0=atof(pst+3);
        }
        if((pst=strstr(str,"e0="))!=NULL)
        {
            _par.e0=atof(pst+3);
        }
        if((pst=strstr(str,"e1="))!=NULL)
        {
            _par.e1=atof(pst+3);
        }
        if((pst=strstr(str,"e2="))!=NULL)
        {
            _par.e2=atof(pst+3);
        }
        if((pst=strstr(str,"vp="))!=NULL)
        {
            _par.vp=atof(pst+3);
        }
        if((pst=strstr(str,"dp="))!=NULL)
        {
            _par.dp=atof(pst+3);
        }
        if((pst=strstr(str,"rho="))!=NULL)
        {
            _par.rho=atof(pst+4);
        }
        if((pst=strstr(str,"stressfactor="))!=NULL)
        {
            _par.stressfactor=atof(pst+13);
        }
        if((pst=strstr(str,"prefactor="))!=NULL)
        {
            _par.prefactor=atof(pst+10);
        }
        if((pst=strstr(str,"sitenumber="))!=NULL)
        {
            _par.sitenumber=atoi(pst+11);
        }
        if((pst=strstr(str,"alpha0="))!=NULL)
        {
            _par._CpG.alpha=atof(pst+7);
        }
        if((pst=strstr(str,"beta0="))!=NULL)
        {
            _par._CpG.beta=atof(pst+6);
        }
        if((pst=strstr(str,"gamma="))!=NULL)
        {
            _par._CpG.gamma=atof(pst+6);
        }
        if((pst=strstr(str,"theta0="))!=NULL)
        {
            _par.theta0=atof(pst+7);
            _par._CpG.theta=_par.theta0;
        }
        if((pst=strstr(str,"X(0)="))!=NULL)
        {
            _X0=atoi(pst+5);
        }
        if((pst=strstr(str,"Ts="))!=NULL)
        {
            _par.Ts=atof(pst+3);
        }
        if((pst=strstr(str,"V="))!=NULL)
        {
            _V=atof(pst+2);
        }
        if((pst=strstr(str,"FT="))!=NULL)
        {
            _par.FT=atoi(pst+3);
        }
        if((pst=strstr(str,"Xmin="))!=NULL)
        {
            _Xmin=atof(pst+5);
        }
        if((pst=strstr(str,"Xmax="))!=NULL)
        {
            _Xmax=atof(pst+5);
        }
        if((pst=strstr(str,"StressQ="))!=NULL)
        {
            _par.StressQ=atoi(pst+8);
        }
        if((pst=strstr(str,"Developed="))!=NULL)
        {
            _par.Developed=atoi(pst+10);
        }
	}
 	fclose(fp);
}

void CStemCell::SetDefaultPar()
{
    _X0 = -1;
    _par.r0 = 0;
    _par.Developed = 0;
    _par.e0 = 1;
    _par.stressfactor = 0;
    _par.prefactor = 1.0;
}

void CStemCell::GetRandForces(double b[][NUMRAND], double x[], int k)
{
}

void CStemCell::GetTrends(double a[], double x[])
{
}

void CStemCell::Update(int mu, double tau)
{
    int ci, mu0;
    double s;
    double R0, P0;
    double d1, d2, dp, vp;
    double Fr;
    
    _t = _t + tau;

    R0 = _R;
    P0 = _P;
    d1 = _par.d1;
    dp = _par.dp;
    vp = _par.vp;
    d2 = d1 - dp;

    _P = _P * exp(-1.0 * dp * tau) + vp * _R * (1.0 - exp(-1.0 * dp * tau))/dp;
    
    ci = (mu-1) / _CpG[1]._NumReact;
    
    if (ci < _par.sitenumber)
    {
        mu0 = ((mu-1) % _CpG[1]._NumReact) + 1;
        _CpG[ci].Update(mu0, tau);
        s=GetState();
        Addnode(_t,s);
        _laststate = s;
        _state = GetStateAve();
    }
    else
    {
        switch(mu - _CpG[1]._NumReact * _par.sitenumber){
            case 1: _R = _R + 1;
                break;
            case 2: _R = _R - 1;
                break;
        }
    }

}

void CStemCell::Addnode(double t, double s)
{
    pend->pnext = new struct node;
    pend = pend->pnext;
    pend->t = _t;
    pend->s = s;
    pend->pnext = NULL;
}

double CStemCell::GetState()
{
    int i;
    double s=0;
    
    for (i=0; i<_par.sitenumber; i++)
    {
        s = s + 1.0*_CpG[i]._state;
    }
    s = s/(2*_par.sitenumber);

    
    return(s);
    
}

void CStemCell::Propensities(double a[])
{
    int i,j;
    double *b0;
    
    b0 = new double[_CpG[1]._NumReact + 1];
    
    for (i=0;i<_par.sitenumber; i++)
    {
        _CpG[i].Propensities(b0);
        for (j=1; j<=_CpG[i]._NumReact; j++)
        {
            a[_CpG[i]._NumReact * i + j] = b0[j];
        }
    }
    
    i = _CpG[1]._NumReact * _par.sitenumber;
    a[i+1] = GetFr();
    a[i+2] = _par.d1 * _R;
    
    a[0] = 0;
    for (i=1; i<=_NumReact; i++)
    {
        a[0] = a[0] + a[i];
    }
    
    delete[] b0;
}

double CStemCell::GetFr()
{
    double f0, r0;
    double Ps, g0;
    double Fr;
    
    if(_par.StressQ==1)
    {
        f0 = _gstress(1.0*_cycle)*_par.f0;
        r0 = _gstress(1.0*_cycle)*_par.r0;
    }
    else
    {
        f0 = _par.f0;
        r0 = _par.r0;
    }
    

    g0 = 1.0;
    Fr = f0 *((1.0-_par.rho) + _par.rho * 1.0/(1.0 + pow(_state/_par.s0, _par.m0)))*g0;
    
    return(Fr);

}

double CStemCell::GetStateAve()
{
    struct node *p;
    double s;
    while(pend->t - phead->t > _par.Ts)
    {
        p=phead;
        phead = phead->pnext;
        delete p;
    }
    p=phead;
    s=0;
    while (p->pnext !=NULL)
    {
        s = s + p->s * (p->pnext->t - p->t);
        p = p->pnext;
    }
    if(pend->t - phead ->t > 0.001)
    {
        s = s/(pend->t - phead ->t);
    }
    else
    {
        s = phead->s;
    }
    return(s);
}

void CStemCell::Pre_OneStep()
{
    int i;
 
    for (i=0; i<_par.sitenumber; i++)
    {
        CpGsiteModification(i);
    }
}

void CStemCell::Post_OneStep()
{
}

DCell CStemCell::CellFateDecision()
{
    int i;
    DCell nextcell;
    
    nextcell.type = 1;  // Always perform cell division
    nextcell.cycle = _cycle;
    nextcell.celltype = _celltype;
    nextcell.R1 = _R;
    nextcell.R2 = _R;
    nextcell.P1 = _MAX(0, Rand.GetNormalDistribution(_P, sqrt(0.5*_P)));
    nextcell.P2 =_MAX(0, Rand.GetNormalDistribution(_P, sqrt(0.5*_P)));
    nextcell.CpG1 = new CpGsite[_par.sitenumber];
    nextcell.CpG2 = new CpGsite[_par.sitenumber];
    
    nextcell.MCell.CpGstate = _IniState.CpGstate;
    nextcell.MCell.R = _IniState.R;
    nextcell.MCell.P = _IniState.P;
    
    for (i=0; i<_par.sitenumber; i++)
    {
        nextcell.CpG1[i]._methyl[0] = _CpG[i]._methyl[0];
        nextcell.CpG1[i]._methyl[1] = 0;
        
        nextcell.CpG2[i]._methyl[0] = _CpG[i]._methyl[1];
        nextcell.CpG1[i]._methyl[1] = 0;
    }
    return(nextcell);
}

void CStemCell::Pre_OneCycle()
{
    int i;
    struct node *p;
    
    _cycle++;
    
    if(!(_MD.MultiCell==1) && _cycle > _MD.NC) _cycle = 0;  // 200 cell cycle for one generation
    
    _ratesupdate1();
    for (i=0; i<_par.sitenumber; i++)
    {
        CpGsiteModification(i);
    }
   
    _t = 0;
    
    phead = new struct node;
    phead->pnext = NULL;
    pend = phead;
    pend->s = GetState();
    pend->t = _t;
    _laststate = pend->s;
    _state = GetStateAve();
    
    SetIniState();
    
}

void CStemCell::DeleteChain(struct node *p)
{
    struct node *p1;
    while (p->pnext!=NULL)
    {
        p1 = p;
        p = p->pnext;
        delete p1;
    }
    delete p;
}

double CStemCell::_f(double x)
{
    double y;
    if(_kg==0)
    {
        y = _defaultf(x);
    }
    else
    {
        switch(_par.FT)
        {
            case 0:
                y = 1.0;
                break;
            case 1:
                y = 0.9058 +  0.06 * atan((x-8)*2);
                break;
            case 2:
                y = 0.8116 +  0.12 * atan((x-8)*2);
                break;
            case 3:
                y = _defaultf(x);
                break;
            case 4:
                y = 0.5604 +  0.28 * atan((x-8)*2);
                break;
            case 5:
                y = 0.4976 +  0.32 * atan((x-8)*2);
                break;
            default:
                y = _defaultf(x);
        }
    }
    if (x<0 || _par.Developed==1) y = 1.0;

    return(y);
}

double CStemCell::_defaultf(double x)
{
    double y;
    y = 0.59 +  0.259 * atan((x-8)*2);
    return(y);
}

double CStemCell::_g(double x)
{
    double y;
    if (x < 20)
    {
        y = 0.507 +  0.323 * atan((x-8)*2);
    }
    else
    {
        if (_celltype == 0)
        {
            y = 0.667 + 0.212 * atan((x-40)*1);
        }
        else
        {
            y = 1.0;
        }
    }
    if (x<0 || _par.Developed==1) y = 1.0;
    return (y);
}

double CStemCell::_gstress(double x)
{
    double y;
    if (_celltype == 0 && _currentgen ==0 && x> (_MD.NC - 40) && x < (_MD.NC - 1))
    {
        y = 1 - _par.stressfactor;
    }
    else
    {
        y = 1;
    }
    return(y);
}

double CStemCell::_h(double x)  // Consentration for TET proteins.
{
    double y;
    if(x<=2)
    {
        y = _par.h1;
    }
    else
    {
        if(_celltype==0)
        {
            y = 1.0 + _par.h0 * (1.0 + 0.637 * atan((x-20)*1)) * (1.0 + 0.637 * atan(-(x-30)/2));
        }
        else
        {
            y = 1.0;
        }
    }
    if (x<0 || _par.Developed==1) y = 1.0;

    return(y);
}

double CStemCell::_e(double x)  // Pre-factor for the effective protein.
{
    double y;
    y=_par.e0;
    
    if( x >=0 && x <= 2)
    {
        y=_par.e1;
    }
    if (_celltype == 0 && x >= 20 && x <= 40)
    {
        y=_par.e2;
    }
    
    return(y);
}

void CStemCell::CpGsiteModification(int i)
{
    _ratesupdate2();
    _CpG[i].Initialization(i, _alpha, _beta, _gamma, _theta,_CpG[i]._methyl);
}

void CStemCell::_ratesupdate1()
{
    _alpha = _par._CpG.alpha * (0.1 + 4.9 * _f(_cycle * 1.0));
    _beta = _par._CpG.beta * _h(_cycle * 1.0);
    _gamma = _par._CpG.gamma;
}

void CStemCell::_ratesupdate2()
{
    double Theta;
    double Ps;
    Ps = _e(_cycle) * _P;
    _par._CpG.theta = (_par.theta0 * pow(_par.K0, _par.n0)/(pow(_par.K0, _par.n0) + pow(Ps/_V,_par.n0)));
    _theta = _par._CpG.theta * (1.0 + 9.0 * _g(_cycle * 1.0));
}

void CStemCell::Post_OneCycle()
{
    DeleteChain(phead);
}

void CStemCell::OneCellCycle(int type)
{
    int step=0;
    
    PreOutPut(_MD.mdcrd);
    PreRun(type);
    
    
    Pre_OneCycle();

    while(_t < _MD.T1)
    {
        if((_MD.ntpx >0) && (step%_MD.ntpx==0))
        {
            OutPut(_t);
        }
        Pre_OneStep();
        Gillespie_OneStep();
        Post_OneStep();
        step++;
    }

    Post_OneCycle();
    PostOutPut();
    PostRun(type);
}


void CStemCell::OutPut(double _t)
{
    fprintf(_fp,"%8.3f",_t);
    fprintf(_fp," %1d %3d %8.3f %8.3f", _celltype, _R, _state, _laststate);
    fprintf(_fp,"\n");
}













