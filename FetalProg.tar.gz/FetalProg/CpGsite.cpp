#include "CpGsite.h"
#include "Random.h"
#include "math.h"

#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include <iostream>
using namespace std;


extern CRandom Rand;

CpGsite::CpGsite()
{
    _methyl[0]=1;
    _methyl[1]=0;
    _NumReact=18;
}

CpGsite::~CpGsite()
{
    
}

void CpGsite::Initialization(int k, double a0, double a1, double a2, double a3, int s[])
{
    _index = k;
    _alpha = a0;
    _beta = a1;
    _gamma = a2;
    _theta = a3;
    
    _methyl[0]=s[0];
    _methyl[1]=s[1];
    _state = (_methyl[0] % 2) + (_methyl[1] % 2);
    CpGtoState();
}

void CpGsite::CpGtoState()
{
    _X = _methyl[0] * 3 + _methyl[1] + 1;
    
}

void CpGsite::StatetoCpG()
{
    _methyl[1] = (_X-1) % 3;
    _methyl[0] = (_X-1) / 3;

}

void CpGsite::Modification(double Tf)
{
    int k;
    _t=0;
    while (_t < Tf)
    {
        Gillespie_OneStep(Tf);
    }
}

void CpGsite::Gillespie_OneStep(double Tf)
{
    double r1, r2, tau, s, s0;
    int mu;
    
    Propensities(_Prop);
    r1=Rand();
    r2=Rand();
    tau = (1/_Prop[0])*log(1/r1);
    s=0.0;
    s0 = r2*_Prop[0];
    
    for (mu = 1; mu<=_NumReact; mu++)
    {
        if(s0 > s && s0 <= s + _Prop[mu])
        {
            break;
        }
        else
        {
            s=s+_Prop[mu];
        }
    }
    
    if(mu>_NumReact) { tau = Tf - _t;}
    
    if(_t+tau<Tf)
    {
        Update(mu,tau);
    }
    else
    {
        _t = _t + tau;
    }
    
}

void CpGsite::Propensities(double a[])
{
    int i;
    for (i=1;i<=_NumReact; i++)
    {
        a[i]=0;
    }
    switch(_X){
        case 1: a[1] = _theta;
            a[2] = _theta;
            break;
        case 2: a[3] = _beta;
            a[4] = _theta;
            break;
        case 3: a[5] = _gamma;
            a[6] = _theta;
            break;
        case 4: a[7] = _alpha;
            a[8] = _beta;
            break;
        case 5: a[9] = _beta*0.1;
            a[10] = _beta*0.1;
            break;
        case 6: a[11] = _gamma;
            a[12] = _beta;
            break;
        case 7: a[13] = _theta;
            a[14] = _gamma;
            break;
        case 8: a[15] = _beta;
            a[16] = _gamma;
            break;
        case 9: a[17] = _gamma;
            a[18] = _gamma;
            break;
    }
    
    a[0] = 0;
    for (i=1; i<=_NumReact; i++)
    {
        a[0] = a[0] + a[i];
    }
}

void CpGsite::Update(int mu, double tau)
{
    _t=_t+tau;
    switch(mu){
        case 1:  _X = 2; break;
        case 2:  _X = 4; break;
        case 3:  _X = 3; break;
        case 4:  _X = 5; break;
        case 5:  _X = 1; break;
        case 6:  _X = 6; break;
        case 7:  _X = 5; break;
        case 8:  _X = 7; break;
        case 9:  _X = 6; break;
        case 10: _X = 8; break;
        case 11: _X = 4; break;
        case 12: _X = 9; break;
        case 13: _X = 8; break;
        case 14: _X = 1; break;
        case 15: _X = 9; break;
        case 16: _X = 2; break;
        case 17: _X = 7; break;
        case 18: _X = 3; break;
    }
    StatetoCpG();
    _state = (_methyl[0] % 2) + (_methyl[1] % 2);
}

