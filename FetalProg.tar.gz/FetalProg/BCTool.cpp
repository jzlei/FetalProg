#include "BCTool.h"

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "time.h"
#include "string.h"
#include <iostream>
using namespace std;

int _currentgen;
struct IMD _MD;
CRandom Rand;

void ReadIPF(char *fn);
void SetParVal(char *str, char const *conststr, char val[]);
void help();
void SetDefault();
void OutputParameter();

int main(int argc, char *argv[])
{
	CSystem *sys;
	char fn[ComLength];
  	if (argc<2)
  	{
  		help();
		exit(0);
  	}
	
	ReadIPF(argv[1]);
    if(_MD.seed > 0) Rand.Initialized(_MD.seed);
	switch(_MD.type){
	case 0:		// Perform Gellispie simulation
				sys = new CSystem(_MD.N);
				if(sys->Initialized())
				{
					sys->Run(_MD.type);
					return(1);
				}
				else
				{
					return(0);
				}
				break;
	case 1:	// Perform Stochastric simulation
	case 2: // Perform Chemical Rate Equation
				sys = new CSystem(_MD.N);
				if(sys->Initialized())
				{
					sys->Run(_MD.type);
					return(1);
				}
				else
				{
					return(0);
				}
				break;
	}
}

void help()
{
	cout<<"Usage: "<<endl;
	cout<<"exec_Fetal inputfile"<<endl;
	cout<<"inputfile: The name of input file."<<endl;
	cout<<" For example: exec_Fetal md.in."<<endl;
}

void ReadIPF(char *fn)
{
	FILE *fp;
	char str[StrLength], *pst;
	if((fp = fopen(fn,"r"))==NULL)
	{
		cout<<"Cannot open the input file."<<endl;
		exit(0);
	}
	SetDefault();
	rewind(fp);
	while(!feof(fp))
	{
		fgets(str,StrLength,fp);
		if(str[0]=='#'){ continue;}
		SetParVal(str, "mdcrd=\"", _MD.mdcrd);
		SetParVal(str, "cellpar=\"",_MD.cellpar);
		SetParVal(str, "cellpargen=\"",_MD.cellpargen);
		SetParVal(str, "mutant=\"",_MD.mutant);
        if((pst=strstr(str,"dt="))!=NULL)
		{
			_MD.dt=atof(pst+3);
		}
		if((pst=strstr(str,"T1="))!=NULL)
		{
			_MD.T1=atof(pst+3);
		}
        if((pst=strstr(str,"ntpx="))!=NULL)
		{
            _MD.ntpx=atoi(pst+5);
        }
        if((pst=strstr(str,"ntpr="))!=NULL)
		{
            _MD.ntpr=atoi(pst+5);
        }
		if((pst=strstr(str,"seed="))!=NULL)
		{
			_MD.seed=atoi(pst+5);
		}
        if((pst=strstr(str,"N="))!=NULL)
		{
            _MD.N=atoi(pst+2);
        }
        if((pst=strstr(str,"NC="))!=NULL)
        {
            _MD.NC=atoi(pst+3);
        }
        if((pst=strstr(str,"NC0="))!=NULL)
        {
            _MD.NC0=atoi(pst+4);
        }
        if((pst=strstr(str,"GC="))!=NULL)
        {
            _MD.GC=atoi(pst+3);
        }
		if((pst=strstr(str,"type="))!=NULL)
		{
            _MD.type=atoi(pst+5);
        }
        if((pst=strstr(str,"MultiCell="))!=NULL)
        {
            _MD.MultiCell=atoi(pst+10);
        }
        if((pst=strstr(str,"Somatic="))!=NULL)
        {
            _MD.Somatic=atoi(pst+8);
        }
        if((pst=strstr(str,"Cellline="))!=NULL)
        {
            _MD.Cellline=atoi(pst+9);
        }
	}
	fclose(fp);
}

void SetParVal(char *str, char const *conststr, char val[])
{
	char *pst;
	if((pst=strstr(str,conststr))!=NULL)
	{
		strcpy(val,pst+strlen(conststr));
		if((pst = strstr(val,"\""))!=NULL)
		{
			val[pst - val] = '\0';
		}			
	}
	return;
}

void OutputParameter()
{
     cout<<"mdcrd="<<_MD.mdcrd<<endl;
	 cout<<"N="<<_MD.N<<endl;
	 cout<<"dt="<<_MD.dt<<endl;
     cout<<"T1="<<_MD.T1<<endl;
	 cout<<"ntpr="<<_MD.ntpr<<endl;
	 cout<<"ntpx="<<_MD.ntpx<<endl;
}

void SetDefault()
{
    _MD.ntpx=0;
    _MD.ntpr=0;
    _MD.N=1;
    _MD.NC0=0;
    _MD.seed=0;
    _MD.MultiCell=0;
    _MD.Somatic=1;
    _MD.Cellline=-1;
}
