#ifndef CONSTANTS_H
#define CONSTANTS_H

//Definition of constants
#define ComLength 100
#define StrLength 1024
#define UNITMAX 2147483647
#define NUMREACT 1300
#define NUMVAR 5
#define NUMRAND 5
#define PI 3.14159
#define POSITIVE 0

#endif