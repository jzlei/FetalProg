#ifndef CPGSITE_H
#define CPGSITE_H


#include <stdio.h>
#include "Constants.h"

class CpGsite{
private:
    double _alpha;   // Dynamical parameters;
    double _beta;
    double _gamma;
    double _theta;
    int _index;
    double _t;
    double _Prop[20];
    
    void CpGtoState();
    void StatetoCpG();
    
public:
    int _NumReact;
    int _methyl[2];
    int _X;
    int _state;
    
    void Initialization(int k, double a0, double a1, double a2, double a3, int s[]);
    void Modification(double Tf);
    
    void Propensities(double *a);
    void Update(int mu,double tau);
    void Gillespie_OneStep(double Tf);
    
    CpGsite();
    ~CpGsite();
    
    friend class CStemCell;
    
};

#endif