#ifndef MODELS_H
#define MODELS_H

#include "CpGsite.h"
#include "CStemCell.h"
#define CELL CStemCell

#endif
