#ifndef BCTOOL_H
#define BCTOOL_H

//Definition of functions
#define _SQUARE(x) ((x)*(x))
#define _MAX(x,y) ((x)>=(y) ? (x):(y))
#define _MIN(x,y) ((x)<=(y) ? (x):(y))
#define _Heaviside(x) ((x)>(0) ? (1.0):(0.0))

#include "Constants.h"

struct IMD{
	char mdcrd[ComLength];	// trajectory file.
	char cellpar[ComLength]; // cell parameter file.
	char cellpargen[ComLength]; // The program to generate cell parameters.
	char mutant[10];        // The name of mutant gene.
	int N;                  // Number of cells.
    int NC;                 // Number of cell cycles.
    int NC0;                // The begining of cell cycles.
    int GC;                 // Number of generations.
	int seed;				// Seed of the random numbers.
	double dt;              // Dynamical parameters.
	double T1;              // Dynamical parameters (period of one cell cycle).
	int type;				// Dynamical type. type = 0 : Gillispie algorithm, type = 1 : Stochastic simulation.
	int ntpr;               // Output the result, if ntpr = 0, then no output.
	int ntpx;                // Output the path result for every ntpx steps. if ntpx = 0, then no result is outputed.
    int MultiCell;           // If Multicell = 1, do multicell simulation, otherwise do single cell simulation.
    int Somatic;             // If Somatic = 1, simulation with somatic cells, otherwise, simulation without somatic cells.
    int Cellline;             // Perform the simulation of cell line from a single cell. If Cellline >=0, we randomly select a from cell cycle = Cellline, otherwise, we do not perform cell line simulation. 
};					    // MD parameters;

#include "Cell.h"
#include "Random.h"
#include "System.h"

#endif


