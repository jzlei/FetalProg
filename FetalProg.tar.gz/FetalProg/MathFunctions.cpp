
#include "MathFunctions.h"

double gammapdf(double a, double b, double x)
{
    double y;
    y = pow(b, a) * gamma(a) * pow(x, a-1) * exp(-x/b);
}