#ifndef RANDOM_H
#define RANDOM_H

//#define RANDMAX 23371.0
//##define RANDPI 3.1415926

class CRandom{
private:

	double x[97];
    double c;
public:
    
	 CRandom();
     CRandom(unsigned seed);
	 double GetValue();                               // Get the value with uniform distribution;
	 double GetNormalDistribution();      // Get the value with standard normal distribution;
	 double GetNormalDistribution(double mu, double sigma);  // Get the value with normal distribution with mean mu and standard deviation sigma
	 void Initialized(unsigned seed);    // Initialzation of the random number

	 double operator()();                   // Get a random value;
	 double GetValue(double a, double b);
	 double operator()(double a, double b);
     double WienerGen();                    // Generate a Wiener process;
};

#endif

