#ifndef CSTEMCELL_H
#define CSTEMCELL_H

#include "Cell.h"
#include "CpGsite.h"

struct ParCpG{
    double alpha, beta, gamma, theta;
};

struct node{
    double t;
    double s;
    struct node *pnext;
};

struct PARStemCell{
    ParCpG _CpG;
    double tau;
    double f0, koff, d1;
    double K0, n0, d2;
    double h0, h1;
    double theta0, s0, m0;
    double K1, r0;
    double e0, e1, e2;
    double rho;
    double vp, dp;
    double stressfactor;
    int sitenumber;
    double Ts;     // The value to calculate the average of s
    int FT;         // function f-type
    int StressQ;
    int Developed; // Set Developed = 1 to study the developed bodies. So that the functions f, g, h are constants.
    
    double prefactor;   // The factor to temporary change the parameters.
};   // System parameters


struct CellState{
    double CpGstate;
    int R;
    double P;
};

struct DCell{
    int type;
    int cycle;
    int celltype;
    CellState MCell;
    double R1, R2;   // mRNA number
    double P1, P2;   // Protein number
    CpGsite *CpG1, *CpG2;    // CpG sites
};


class CStemCell:public CCell{

private:

    struct node *phead;
    struct node *pend;
    double _X0;     // The initial value;
    double _Xmin, _Xmax;
	PARStemCell _par;
    CpGsite *_CpG;
    CellState _IniState;
    double _state;  // The state of average DNA methylation
    double _laststate;  // The state of the last state of DNA methylation
    int _R;         // Number of mRNA
    double _P;      // Number of protein
    double _V;      // The volum of a cell
    double _alpha, _beta, _gamma, _theta;
    
    int _cycle;     // cycle number
    int _celltype;  // _celltype = 0 for germ cells, and _celltype = 1 for somatic cells
   
    
    // Factors for the DNA methylation rate during fetal reprogramming. Here x is the cell cycle
    double _f(double x);
    double _defaultf(double x);
    double _g(double x);
    double _h(double x);
    double _e(double x);
    double _gstress(double x);
    void _ratesupdate1();
    void _ratesupdate2();
    
	void ReadPar(char fpar[]);
    void SetDefaultPar();
    void CpGsiteModification(int i);
    double GetState();
    double GetStateAve();
    double GetFr();
    void DeleteChain(struct node *p);
    void Addnode(double t, double s);
    void SetIniState();
	
	// Begin Stochastic simulation
	void GetRandForces(double b[][NUMRAND], double x[],int k);
	void GetTrends(double a[], double x[]);
	// End Stochastic simulation	
	
	// Begin Gillespie algorithm
	void Propensities(double a[]);
	void Update(int mu, double tau);
	// End of Gillespie algorithm

    void Pre_OneCycle();
    void Pre_OneStep();
    void Post_OneStep();
    void Post_OneCycle();
    
    void OutPut(double _t);
	
	
public:
    int _kg;        // Represent the generation

	CStemCell();
	~CStemCell();
	
	bool Initialized(int k, char fpar[]);
    bool Initialized(int k, char fpar[], int cycle, int celltype);
    
    void OneCellCycle(int type);
    
    DCell CellFateDecision();

	friend class CSystem;
};

#endif
