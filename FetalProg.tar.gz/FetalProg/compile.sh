g++ -c BCTool.cpp
g++ -c Cell.cpp
g++ -c System.cpp
g++ -c CpGsite.cpp
g++ -c CStemCell.cpp
g++ -c Random.cpp
g++ BCTool.o Cell.o System.o CpGsite.o CStemCell.o Random.o -o exec_Fetal
