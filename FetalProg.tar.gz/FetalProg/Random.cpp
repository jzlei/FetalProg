#include "Random.h"

#define RANDMAX 23371.0
#define RANDPI 3.1415926

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "time.h"

CRandom::CRandom()
{
    int i;
    time_t t;
    double f;
    srand( (unsigned) time(&t));
    for (i = 0; i < 97; i++)
    {
        f = 1.0*rand();
        x[i] = (1.0*fmod(f,RANDMAX))/RANDMAX;
    }
    c = (1.0*fmod(rand(),RANDMAX))/RANDMAX;
}

CRandom::CRandom(unsigned seed)
{
    Initialized(seed);
}

void CRandom::Initialized(unsigned seed)
{
    int i;
    double f;
    srand(seed);
    for (i = 0; i < 97; i++)
    {
        f = 1.0*rand();
        x[i] = (1.0*fmod(f,RANDMAX))/RANDMAX;
    }
    c = (1.0*fmod(rand(),RANDMAX))/RANDMAX;
}

double CRandom::GetValue()
{
    double x0,U;
    int r = 0, s = 64;
    int i;
    double d = 7654321.0/16777216.0, d0 = 1677213.0/1677216.0;
    double f;
    if (x[r] >= x[s])
    {
        x0 = x[r] - x[s];
    }
    else
    {
        x0 = x[r] - x[s] + 1;
    }
    if ( c >= d)
    {
        c = c - d;
    }
    else
    {
        c = c - d + d0;
    }
    if (x0 >= c)
    {
        U = x0 - c;
    }
    else
    {
        U = x0 - c + d0;
    }
    for (i = 0; i < 96; i++)
    {
        x[i] = x[i+1];
    }
    x[96] = fmod(x0,1);
    c = fmod(c,1);
    f = fmod(U,1);
    return(f);
}

// Get the value with standard normal distribution;
double CRandom::GetNormalDistribution()
{
    double f1,f2,x;
    f1 = GetValue();
    f2 = GetValue();
    x = sqrt(-2*log(f1))*cos(2*RANDPI*f2);
    return(x);
}

// Get the value with normal distribution with mean mu and standard deviation sigma
double CRandom::GetNormalDistribution(double mu, double sigma)
{
    double x;
    x = GetNormalDistribution();
    x = sigma*x+mu;
    return(x);
}

double CRandom::operator()()
{
    return(GetValue());
}

double CRandom::operator()(double a, double b)
{
    return(GetValue(a,b));
}


// Obtain a random value from the interval [a,b]
double CRandom::GetValue(double a, double b)
{
    return(a + (b-a)*GetValue());
}

double CRandom::WienerGen()
{
    double f1,f2,x;
    f1 = GetValue();
    f2 = GetValue();
    x = sqrt(-2*log(f1))*cos(2*RANDPI*f2);
    return(x);
}
