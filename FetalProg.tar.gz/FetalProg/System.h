#ifndef SYSTEM_H
#define SYSTEM_H


#include "models.h"

class CSystem{
private:
	int _NumCell;		// Number of cells;
    int _MaxNumCell;    // Maximal cell number.
    
    int _N0;
    int _N1;
    
    FILE * _fmdsys;
    
	CELL *_cells;	// Cells.
    

	void OutPutCells(double t);
	void OutPutSys(FILE *fp, double t);
	void OutPutSys(FILE *fp);
    void RunOneCellCycle(int type, int ngeneration, int ncellcycle);
    
public:
	CSystem();
	~CSystem();
	
	CSystem(int N);

	CELL& operator()(int indx); // Edit to return the type of your own class.

	bool Initialized();
	void Run(int type);
    
    void SystemUpdate(int cycles);
    void Fertilization();
    void SelectOneCell(int k, int cycle);
};

#endif