
#ifndef ____MathFunctions__
#define ____MathFunctions__

#include <stdio.h>

double gammapdf(double alpha, double beta, double x);

#endif /* defined(____MathFunctions__) */
