#include "System.h"
#include "BCTool.h"

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "time.h"
#include "string.h"
#include <iostream>
using namespace std;

extern int _currentgen;
extern struct IMD _MD;
extern CRandom Rand;

CSystem::CSystem()
{
	_NumCell = 0;
}

CSystem::CSystem(int N)
{
	_NumCell = N;
    if(_MD.MultiCell==1)
    {
        _MaxNumCell = 1024* _NumCell;
    }
    else
    {
        _MaxNumCell = _NumCell;
    }
	
	// Change the class_name to choose different model.
	_cells = new CELL[_MaxNumCell];
}

CSystem::~CSystem()
{
     delete _cells;
}

bool CSystem::Initialized()
{
	int k;
    
    for (k=1; k<=_MaxNumCell; k++)
    {
        (*this)(k).Initialized(k, _MD.cellpar);
	}
    return(true);
}

void CSystem::SystemUpdate(int cycles)
{
    int k,i;
    int Ntemp;
    double *Rtemp;
    double *Ptemp;
    double p0;
    double pgermcell;
    DCell *nextcell;
    
    p0 = 1.0*_MaxNumCell/(2.0*_NumCell);
    nextcell = new DCell[_NumCell+1];
    
    if(_MD.Somatic==1)
    {
        pgermcell = 0.5;    // We consider somatic cells.
    }
    else
    {
        pgermcell = 1.0;    // We do not consider somatic cells.
    }
    for (k=1; k<=_NumCell; k++)
    {
        nextcell[k]=(*this)(k).CellFateDecision();
    }
    Ntemp=0;
    
    _N0=0;
    _N1=0;
    
    for (k=1; k<=_NumCell; k++)
    {
        if (Rand()<p0 && Ntemp < _MaxNumCell)
        {
            Ntemp++;
            if(cycles == 15)
            {
                if(Rand() < pgermcell)
                {
                    (*this)(Ntemp).Initialized(Ntemp, _MD.cellpar,nextcell[k].cycle, 0);
                }
                else
                {
                    (*this)(Ntemp).Initialized(Ntemp, _MD.cellpar,nextcell[k].cycle, 1);
                }
            }
            else
            {
                (*this)(Ntemp).Initialized(Ntemp, _MD.cellpar,nextcell[k].cycle, nextcell[k].celltype);
            }

            (*this)(Ntemp)._R = nextcell[k].R1;
            (*this)(Ntemp)._P = nextcell[k].P1;
            for (i=0; i<(*this)(Ntemp)._par.sitenumber; i++)
            {
                (*this)(Ntemp)._CpG[i]._methyl[0] = nextcell[k].CpG1[i]._methyl[0];
                (*this)(Ntemp)._CpG[i]._methyl[1] = nextcell[k].CpG1[i]._methyl[1];
            }

            if((*this)(Ntemp)._celltype==0)
            {
                _N0++;
            }
            else
            {
                _N1++;
            }
        }
        if (Rand()<p0 && Ntemp < _MaxNumCell)
        {
            Ntemp++;
            if(cycles == 15)
            {
                if(Rand() < pgermcell)
                {
                    (*this)(Ntemp).Initialized(Ntemp,_MD.cellpar,nextcell[k].cycle,0);
                }
                else
                {
                    (*this)(Ntemp).Initialized(Ntemp,_MD.cellpar,nextcell[k].cycle,1);
                }
            }
            else
            {
                (*this)(Ntemp).Initialized(Ntemp,_MD.cellpar,nextcell[k].cycle, nextcell[k].celltype);
            }
            
            (*this)(Ntemp)._R = nextcell[k].R2;
            (*this)(Ntemp)._P = nextcell[k].P2;
            for (i=0; i<(*this)(Ntemp)._par.sitenumber; i++)
            {
                (*this)(Ntemp)._CpG[i]._methyl[0] = nextcell[k].CpG2[i]._methyl[0];
                (*this)(Ntemp)._CpG[i]._methyl[1] = nextcell[k].CpG2[i]._methyl[1];
            }
            
            if((*this)(Ntemp)._celltype==0)
            {
                _N0++;
            }
            else
            {
                _N1++;
            }
        }
    }
    _NumCell = Ntemp;
    
    delete[] nextcell;
}

void CSystem::Fertilization()
{
    int k;
    int i;
    
    i=0;
    for (i=0; i<=_MaxNumCell; i++)
    {
        k = floor(_NumCell*Rand())+1;
        if((*this)(k)._celltype==0) break;
    }
    if(i>=_MaxNumCell)
    {
        printf("No germ cell after %d trails: (%d %d %d).\n", i, _NumCell,_N0,_N1);
        exit(0);
        
    }
    
    SelectOneCell(k, 0);
    (*this)(1).SetIniState();
}

void CSystem::SelectOneCell(int k, int cycle)
{
    int i;
    
    (*this)(1).Initialized(1,_MD.cellpar,cycle,(*this)(k)._celltype);
    (*this)(1)._R = (*this)(k)._R;
    (*this)(1)._P = (*this)(k)._P;
    _NumCell = 1;
    for (i=0; i< (*this)(k)._par.sitenumber; i++)
    {
        (*this)(1)._CpG[i]._methyl[0] = (*this)(k)._CpG[i]._methyl[0];
        (*this)(1)._CpG[i]._methyl[1] = (*this)(k)._CpG[i]._methyl[1];
    }
    (*this)(1).Pre_OneCycle();
}

void CSystem::Run(int type)
{
    int kg;
    int k, k0;
    FILE *fmdsys;
    char fn[ComLength];
    sprintf(fn,"%s.dat",_MD.mdcrd);
    if((fmdsys = fopen(fn,"w"))==NULL)
    {
        cout<<"Cannot open the file mdsys."<<endl;
        exit(0);
    }
    
    _fmdsys = fmdsys;
    if(_MD.Cellline < 0)
    {
        OutPutSys(_fmdsys, 0);
    }
    for (kg=0; kg<=_MD.GC; kg++)
    {
        _currentgen = kg;
        for (k=_MD.NC0; k<=_MD.NC; k++)
        {
            if(_MD.Cellline>=0)
            {
                if(k==_MD.Cellline)
                {
                    k0=floor(_NumCell*Rand())+1;
                    SelectOneCell(k0, k);
                    (*this)(1)._R=80;      // Perform the perturbation
                    (*this)(1)._P = (*this)(1)._R * ((*this)(1)._par.vp/(*this)(1)._par.dp);
                    (*this)(1).SetIniState();
                }
            }
            if(!(kg>0 && k==0))
            {
                RunOneCellCycle(type,kg, k);
            }
            if(_MD.Cellline < 0 || (k >= _MD.Cellline))
            {
                OutPutSys(_fmdsys, k*1.0);
            }
            if(_MD.MultiCell==1)
            {
                SystemUpdate(k);
            }
        }
        if(_MD.MultiCell==1)
        {
            Fertilization();
        }
    }
    fclose(fmdsys);
}

void CSystem::RunOneCellCycle(int type, int ngeneration, int ncellcycle)
{
    int k;
    
    for (k=1; k<=_NumCell; k++)
    {
        (*this)(k)._kg=ngeneration;
        (*this)(k).OneCellCycle(type);
    }
}

void CSystem::OutPutSys(FILE *fp, double t)
{
	
	int k;
	int ocell;
	fprintf(fp,"%8.3f",t);
	for(k = 1; k<= _NumCell; k++)
	{
	// Edit to change you output items.
        fprintf(fp," %1d %3d %8.3f %8.3f", (*this)(k)._celltype, (*this)(k)._R, (*this)(k)._state, (*this)(k)._laststate);
    }
    for(k = _NumCell+1; k<= _MaxNumCell; k++)
    {
        // Edit to change you output items.
        fprintf(fp," %1d %1d %1d %1d", -1, -1, -1, -1);
    }
	fprintf(fp,"\n");
}

void CSystem::OutPutSys(FILE *fp)
{
}

void CSystem::OutPutCells(double t)
{
	int k;
	for(k = 1; k<= _NumCell; k++)
	{
		   (*this)(k).OutPut(t);
	}
}


CELL& CSystem::operator()(int indx)
{
    if(indx>0 && indx<=_MaxNumCell)
    {
        return *(_cells+(indx-1));
    }
    else
    {
        cout<<"Err<< CSystem () >>Dimensional error"<<endl;
        exit(0);
    }
}
